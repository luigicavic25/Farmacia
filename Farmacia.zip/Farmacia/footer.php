<?php
// footer.php
?>
</div> <!-- .container -->
<footer class="small">
  Sistema Farmácia — Desenvolvido por Luigi, Rafael & Tainara • <?= date('Y') ?>
</footer>
</body>
</html>
